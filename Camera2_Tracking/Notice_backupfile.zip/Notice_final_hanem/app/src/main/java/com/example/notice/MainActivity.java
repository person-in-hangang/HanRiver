package com.example.notice;

import androidx.appcompat.app.AppCompatActivity;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    FragmentManager fm;
    FragmentTransaction tran;
    WeatherFragment weather_f;
    RealtimeFragment realtime_f;
    ReportFragment report_f;
    SettingFragment setting_f;

    FrameLayout frame_layout;
    Button realtimeB,weatherB,reportB,settingB;

    String msg="";

    public void createNotificationChannel(){
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("notice_alarm", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        createNotificationChannel();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("jinajina",msg);

        realtime_f = new RealtimeFragment();
        report_f = new ReportFragment();
        setting_f = new SettingFragment();
        setFrag(0);

       frame_layout=findViewById(R.id.fragment);

        realtimeB=findViewById(R.id.realtime);
        reportB=findViewById(R.id.report);
        settingB=findViewById(R.id.setting);

        realtimeB.setOnClickListener(this);
        reportB.setOnClickListener(this);
        settingB.setOnClickListener(this);

    }

    @Override
    public void onClick(View v){
        switch (v.getId()){

            case R.id.realtime:
                setFrag(0);
                break;
            case R.id.report:
                setFrag(2);
                break;
            case R.id.setting:
                setFrag(3);
                break;
        }
    }

    public void setFrag(int n) {    //프레그먼트 교체 메소드
        fm = getFragmentManager();
        tran = fm.beginTransaction();
        switch (n) {
            case 0:
                tran.replace(R.id.fragment,realtime_f);
                tran.commit();
                break;
            case 2:
                tran.replace(R.id.fragment,report_f);
                tran.commit();
                break;
            case 3:
                tran.replace(R.id.fragment,setting_f);
                tran.commit();
                break;
        }
    }


}
